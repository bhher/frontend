import ExampleApp from './examples/ExampleApp';

function App() {
  return <ExampleApp />;
}

export default App;